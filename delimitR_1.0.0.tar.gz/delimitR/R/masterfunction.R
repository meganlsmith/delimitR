#' Generate input files for fastsimcoal2
#' @export
#' @param tree A guide tree specified in Newick format. Tip labels should be 0 to (nspec-1).
#' @param samplesizes A vector of sample sizes.
#' @param nspec The number of potential species.
#' @param popsizeprior Prior for population sizes.
#' @param divtimeprior Prior on divergence times.
#' @param maxinterval The maximum coalescent interval for which to consider migration.
#' @param nsnps The number of SNPs to simulate.
#' @param prefix A prefix for naming output filess.
#' @param migrateprior Prior on migration rates.
#' @param myrules A list of rules for the order of coalescence times.

setup_fsc2 <- function(tree, samplesizes, nspec, popsizeprior,divtimeprior, migrateprior, maxinterval, nsnps, prefix, myrules = NULL){
  mydir <- dir  # set a working directory to ensure all files are saved correctly
  checkinput(tree, nspec, samplesizes, popsizeprior, divtimeprior) # check the user input for errors
  theparsed <- parsetree(tree)
  if(  exists('theparsed') == FALSE) {
    stop("There was an issue parsing your guide tree")
  }
  myhistory <- makehistoryvector(theparsed) # get a simple list of coalescent events
  nhistevents <- length(myhistory) # count the coalescent events
  ntimes <- length(theparsed) # count the coalescent intervals
  theeventhistory <- gethistory(nhistevents,myhistory) # create fsc2 style events for each coalescent event
  eventgrid <- geteventgrid(theeventhistory) # get a matrix of 0s and 1s for when you can and cannot collapse nodes
  mycollapsedhist <- historieswithcollapse(eventgrid, theeventhistory) # create fsc2 style events for all coalescent events with all possible collapses of nodes. This will be a list of lists.
  migrationlist <- generatemigratelist(maxinterval, mycollapsedhist, theparsed, theeventhistory) # get a list of migration events
  myhistoricinfo <- generatefullmighistory(maxinterval, nspec, migrationlist, mycollapsedhist)
  writetpl_mig_full(samplesizes, nhistevents, myhistory, nsnps, prefix, theparsed, mycollapsedhist, myhistoricinfo)
  if(length(myrules) == 0){
    writeest(samplesizes = samplesizes,popsizeprior= popsizeprior,nhistevents= nhistevents,divtimeprior=divtimeprior,filename=prefix,mycollapsedhist = mycollapsedhist,myhistoricinfo= myhistoricinfo,migrateprior= migrateprior,migrationlist=migrationlist)
  }
  else{
    writeest_rules(samplesizes = samplesizes,popsizeprior= popsizeprior,nhistevents= nhistevents,divtimeprior=divtimeprior,filename=prefix,mycollapsedhist = mycollapsedhist,myhistoricinfo= myhistoricinfo,migrateprior= migrateprior,migrationlist=migrationlist, rules = myrules)
  }
}
