#' Generate migration list
#' @keywords internal
generatemigratelist <- function(maxinterval,mycollapsedhist,newparse,thehistory){
  migrationevents<- list()
  for (i in 1:length(mycollapsedhist)){
    thismigration <- list()
    counter = 1
    for (j in 1:length(mycollapsedhist[[i]])){
      coalescentinterval <- NA
      theevent <- unlist(mycollapsedhist[[i]][j])
      theeventsplit <- strsplit(theevent,split=" ")
      divtime <- theeventsplit[[1]][1]
      pop1 <- theeventsplit[[1]][2]
      pop2 <- theeventsplit[[1]][3]
      if (divtime=="0") {
        for (k in 1:length(newparse)) {
          for (l in 1:length(newparse[[k]])) {
            checkpop1 <- newparse[[k]][[l]][1]
            checkpop2 <- newparse[[k]][[l]][3]
            if((checkpop1==pop1&checkpop2==pop2)|(checkpop1==pop2&checkpop2==pop1)){
              coalescentinterval <- k
            }
          }
        }
        if (coalescentinterval == 1) {
          next
        }
        else {
          potentialmigstart<- list()
          for(m in 1:length(newparse[[(coalescentinterval-1)]])){
            historystring<- newparse[[(coalescentinterval-1)]][[m]]
            secondpop1check <- historystring[[1]]
            secondpop2check <- historystring[[3]]
            if(pop1==secondpop1check|pop1==secondpop2check|pop2==secondpop1check|pop2==secondpop2check){
              for(n in 1:length(thehistory)){
                historystring2<- strsplit(thehistory[[n]],split=" ")
                thirdpop1check <- historystring2[[1]][2]
                thirdpop2check <- historystring2[[1]][3]
                if((thirdpop1check==secondpop1check&thirdpop2check==secondpop2check)|(thirdpop2check==secondpop1check&thirdpop1check==secondpop2check)){
                  potentialmigstart <- c(potentialmigstart,historystring2[[1]][1])
                }
              }
            }
          }
        }
      }
      else if (divtime!="0") {
        for (k in 1:length(newparse)) {
          for (l in 1:length(newparse[[k]])) {
            checkpop1 <- newparse[[k]][[l]][1]
            checkpop2 <- newparse[[k]][[l]][3]
            if((checkpop1==pop1&checkpop2==pop2)|(checkpop1==pop2&checkpop2==pop1)){
              coalescentinterval <- k
            }
          }
        }
        if(coalescentinterval <= maxinterval){
          if(coalescentinterval==1){
            tmigstart <- 0
          }
          else{
            potentialmigstart<- list()
            for(m in 1:length(newparse[[(coalescentinterval-1)]])){
              historystring<- newparse[[(coalescentinterval-1)]][[m]]
              secondpop1check <- historystring[[1]]
              secondpop2check <- historystring[[3]]
              if(pop1==secondpop1check|pop1==secondpop2check|pop2==secondpop1check|pop2==secondpop2check){
                for(n in 1:length(thehistory)){
                  historystring2<- strsplit(thehistory[[n]],split=" ")
                  thirdpop1check <- historystring2[[1]][2]
                  thirdpop2check <- historystring2[[1]][3]
                  if((thirdpop1check==secondpop1check&thirdpop2check==secondpop2check)|(thirdpop2check==secondpop1check&thirdpop1check==secondpop2check)){
                    potentialmigstart <- c(potentialmigstart,historystring2[[1]][1])
                  }
                }
              }
            }
          }
          potentialmigend <- divtime
          if(coalescentinterval==1){
            thismigration[[counter]] <- list(pop1,pop2,coalescentinterval,tmigstart,potentialmigend)
            counter <- counter+1
          }
          else{
            thismigration[[counter]] <- list(pop1,pop2,coalescentinterval,unlist(potentialmigstart),potentialmigend)
            counter <- counter+1
          }
        }
      }
    }
    if(length(thismigration)==0){
      migrationevents[[i]]<- NA
    }
    else{
      migrationevents[[i]]<- thismigration
    }
  }
  return(migrationevents)
}

#' Generate migration list
#' @keywords internal
#' @import utils
generatefullmighistory <- function(maxinterval,nspec,migrationlist,mycollapsedhist){
  historiceventswmig <- list()
  migmatrixlist <- list()
  for(i in 1:length(migrationlist)){ ## we're looping through each collapsed history
    thismiglist <- list()
    if(is.na(migrationlist[[i]][1])){ ## if there is no list of migration events:
      historiceventswmig[[i]]<-mycollapsedhist[i]
      migmatrixlist[[i]]<- NA## just add the collapse history to our list of historic events
    }
    else{ ## if there is a lis to fmigration events
      historiceventswmig[[i]]<-mycollapsedhist[i] ## first, add the collapse history
      thecount<- 2
      mycombos <- list()
      for(j in 1:length(migrationlist[[i]])){ ## then, we need to loop through each of these migration events
        mycombos <- c(mycombos,utils::combn(1:length(migrationlist[[i]]),j,simplify=FALSE)) ## we want all combos of potential migration events.
      }
      #    cat("This means there are ", length(mycombos), "possible scenarios, in addition to the simple collapse events\n")
      #    print(mycombos)## this generates a list of all possible combos of migration events
      for(k in 1:length(mycombos)){ ## now, we need to loop through these combinations and write a historical event for each of them
        counter <- 1
        histlistadd <- list()
        coalescentsconsidered <- list()
        histlistadd <- c(histlistadd, mycollapsedhist[[i]])
        migtoadd <- list()
        migcount2 <- 1
        migcount <- 1
        poplist <- list()
        #      print(mycombos[[k]][[1]])
        for(l in 1:length(mycombos[[k]])){
          eventtocheck <- mycombos[[k]][[l]]
          migevent <- migrationlist[[i]][eventtocheck]
          pop1 <- migevent[[1]][[1]]
          pop2 <- migevent[[1]][[2]]
          coalescentinterval <- migevent[[1]][[3]]
          tmigstart <- migevent[[1]][[4]]
          tmigend <- migevent[[1]][[5]]
          if (tmigstart[1] != 0) {
            checkforit <- FALSE
            for(o in 1:length(histlistadd)){
              checkhist <- strsplit(histlistadd[[o]], split = " ")[[1]][1]
              for( a in 1:length(tmigstart)){
                if (checkhist == tmigstart[a] & checkforit == FALSE){
                  checkforit <- TRUE
                }
              }
            }
            if(checkforit ==FALSE){
              coalescentinterval <- coalescentinterval - 1
            }
          }
          poplist[[l]] <- list(pop1,pop2,coalescentinterval)
          if( coalescentinterval %in% coalescentsconsidered){
            next
          }
          if(tmigstart[1] == 0 ){
            histtoadd <- paste('0 0 0 0 1 0 ',counter,sep="")
            histlistadd <- c(histlistadd, histtoadd)
            coalescentsconsidered <- c(coalescentsconsidered,coalescentinterval)
          }
          else if (tmigstart[1] != 0) {
            checkforit <- FALSE
            for(o in 1:length(histlistadd)){
              checkhist <- strsplit(histlistadd[[o]], split = " ")[[1]][1]
              for( a in 1:length(tmigstart)){
                if (checkhist == tmigstart[a] & checkforit == FALSE){
                  histtoadd2 <- paste('Tmig', counter, '$ 0 0 0 1 0 ',counter,sep="")
                  histlistadd <- c(histlistadd, histtoadd2)
                  checkforit <- TRUE
                  coalescentsconsidered <- c(coalescentsconsidered,coalescentinterval)
                }
              }
            }
            if(checkforit ==FALSE){
              histtoadd <- paste('0 0 0 0 1 0 ',counter,sep="")
              histlistadd <- c(histlistadd, histtoadd)
              coalescentsconsidered <- c(coalescentsconsidered,coalescentinterval)
            }
          }
          counter<- counter+1
        }
        historiceventswmig[[i]][[thecount]]<- histlistadd
        thecount <- thecount+1
        for(n in 1:maxinterval){
          migmatrix <- matrix(data=rep(0, (nspec*nspec)),nrow=nspec, ncol=nspec)
          for(m in 1:length(poplist)){
            thepops <-unlist(poplist[[m]])
            num1 <- as.numeric(thepops[1])+1
            num2 <- as.numeric(thepops[2])+1
            coalinterval <- as.numeric(thepops[3])
            if(coalinterval==n){
              migmatrix[num1,num2]<- paste('MIG',m,'$',sep="")
              migmatrix[num2,num1]<- paste('MIG',m,'$',sep="")
            }
            #          migmatrixlist <- c(migmatrixlist,migtoadd)
          }
          if(sum(migmatrix==0)==nspec**2){
            next
          }
          else{
            migtoadd[[migcount2]] <- migmatrix
            migcount2 <- migcount2+1
          }
        }
        thismiglist<- c(thismiglist,list(migtoadd))
        migcount<- migcount+1
        ##      print(migrationlist[[i]][[k]])
      }
    }
    migmatrixlist[[i]] <- thismiglist
  }
  toreturn <- list(historiceventswmig,migmatrixlist)
  return(toreturn)
}


