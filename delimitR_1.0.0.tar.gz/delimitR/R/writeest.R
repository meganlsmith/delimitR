#' Generate .est files
#' @keywords internal
writeest <- function(samplesizes,popsizeprior,nhistevents,divtimeprior,filename,mycollapsedhist,myhistoricinfo,migrateprior,migrationlist){
  estfilecount <- 1 # initiate a counter for naming the .est files
  for(a in 1:length(myhistoricinfo[[1]])){ # for each collapse scenario
    for(b in 1:length(myhistoricinfo[[1]][[a]])){ # for each migration scenario within each collapse scenario
      migrationcount <- 0
      checklength<- length(myhistoricinfo[[1]][[a]][[b]]) # check to see if it includes migration
      comparelength <- length(mycollapsedhist[[1]])
      if(checklength==comparelength){ # if there is no migration
        samplesize <- samplesizes # make a vector of sample sizes
        popsizes <- c() # make an empty vector to store the population sizes
        for(c in 1:length(samplesize)){ # loop through the vector of sample sizes
          popsizes[c] <- paste('N',(c-1),'$',sep='') # and name the pop size variables
        }
        mylines <- list() # create an empty list for the lines to be written out
        mylines[1] <- '// Search ranges and rules file'
        mylines[2] <- '// ****************************'
        mylines[3] <- '[PARAMETERS]'
        mylines[4] <- '//#isInt? #name   #dist.#min  #max'
        mylines[5] <- '//all Ns are in number of haploid individuals'
        for(d in 1:length(samplesize)){ # write the pop size priors out.
          mylines[5+d]<-paste(1,popsizes[d],"unif",popsizeprior[[d]][1],popsizeprior[[d]][2],'output',sep='   ')
        }
        divcount = 0
        for (e in 1:nhistevents){ # for each historic event
          divtime <- paste('Tdiv',e,'$',sep='') # get the name of the divtime
          for (f in 1:length(myhistoricinfo[[1]][[a]][[b]])) {
            checkdivtime <- myhistoricinfo[[1]][[a]][[b]][[f]]
            checkdivtime <- strsplit(checkdivtime, split=" ")
            checkdivtime <- checkdivtime[[1]][1]
            if (divtime == checkdivtime) { # if the divtime is not zero for this model
              mylines[6+d+divcount]<-paste(1,divtime,"unif",divtimeprior[[e]][1],divtimeprior[[e]][2],'output',sep='   ') # write the line out
              divcount <- divcount + 1
            }
          }
        }
        mylines[6+d+divcount] <- ''
        mylines[6+d+divcount+1] <- '[RULES]'
        mylines[6+d+divcount+2] <- ''
        mylines[6+d+divcount+3] <- '[COMPLEX PARAMETERS]'
        write(paste(mylines,sep='\n'), file=paste(filename,'_',estfilecount,'.est',sep=""))
        estfilecount <- estfilecount+1
      }
      else if (checklength > comparelength) {
        samplesize <- samplesizes # make a vector of sample sizes
        popsizes <- c() # make an empty vector to store the population sizes
        for(c in 1:length(samplesize)){ # loop through the vector of sample sizes
          popsizes[c] <- paste('N',(c-1),'$',sep='') # and name the pop size variables
        }
        mylines <- list() # create an empty list for the lines to be written out
        mylines[1] <- '// Search ranges and rules file'
        mylines[2] <- '// ****************************'
        mylines[3] <- '[PARAMETERS]'
        mylines[4] <- '//#isInt? #name   #dist.#min  #max'
        mylines[5] <- '//all Ns are in number of haploid individuals'
        for(d in 1:length(samplesize)){ # write the pop size priors out.
          mylines[5+d]<-paste(1,popsizes[d],"unif",popsizeprior[[d]][1],popsizeprior[[d]][2],'output',sep='   ')
        }
        divcount = 0
        for (e in 1:nhistevents){ # for each historic event
          divtime <- paste('Tdiv',e,'$',sep='') # get the name of the divtime
          for (f in 1:length(myhistoricinfo[[1]][[a]][[b]])) {
            checkdivtime <- myhistoricinfo[[1]][[a]][[b]][[f]]
            checkdivtime <- strsplit(checkdivtime, split=" ")
            checkdivtime <- checkdivtime[[1]][1]
            if (divtime == checkdivtime) { # if the divtime is not zero for this model
              mylines[6+d+divcount]<-paste(1,divtime,"unif",divtimeprior[[e]][1],divtimeprior[[e]][2],'output',sep='   ') # write the line out
              divcount <- divcount + 1
            }
          }
        }
        migration <- length(myhistoricinfo[[1]][[a]][[b]])-length(mycollapsedhist[[1]]) # how many migration events are there
        migcount <- 0
        for (g in 1:migration){ # for each migration event
          matrixtowrite <- myhistoricinfo[[2]][[a]][[b-1]][[g]]
          matrixtowrite <- as.factor(matrixtowrite)
          matrixtowritelevs <- levels(matrixtowrite)
          matrixtowritelevs <- matrixtowritelevs[which(matrixtowritelevs != "0")]
          for (h in 1:length(matrixtowritelevs)){
            mylines[7+d+(divcount-1)+migcount]<- paste(0,matrixtowritelevs[h],"unif",migrateprior[[1]][1],migrateprior[[1]][2],'output',sep='   ')
            migcount <- migcount + 1
          }
        }
        mylines[7+d+(divcount-1)+migcount] <- ''
        mylines[7+d+(divcount-1)+1+migcount] <- '[RULES]'
        mylines[7+d+(divcount-1)+2+migcount] <- ''
        mylines[7+d+(divcount-1)+3+migcount] <- '[COMPLEX PARAMETERS]'
        # let's look at the migration matrices
        thematrices <- myhistoricinfo[[2]][[a]][[b-1]]
        linecount <- 7+d+(divcount-1)+3+migcount+1
#        print(thematrices)
        # for each  matrix, we need a start time and an end time.
        # first, we need to figure out which populations each migration event is between
        for (i in 1:length(thematrices)) { # create a list of the population indices for the migration events
          matrixtocheck <- thematrices[[i]]
          nonzero <- (which(matrixtocheck != 0, arr.ind = T))
          nonzero <- nonzero - 1
        # now, we should look through the migration list and get a start and endtime for each of those events
          nonzeroindex <- 1
          migstart <- list()
          migend <- list()
          for (j in 1:(nrow(nonzero)/2)){
            nonzerotocheck <- nonzero[nonzeroindex,] # get the population numbers
            pop1 <- nonzerotocheck[1]
            pop2 <- nonzerotocheck[2]
            nonzeroindex <- nonzeroindex + 2
            miglistcheck <- migrationlist[[a]]
            for (k in 1:length(miglistcheck)) {
              miglistchecknow <- miglistcheck[[k]]
              pop1check <- as.numeric(miglistchecknow[[1]])
              pop2check <- as.numeric(miglistchecknow[[2]])
              coalescentinterval <- as.numeric(miglistchecknow[[3]])
              startcheck <- miglistchecknow[[4]]
              stopcheck <- miglistchecknow[[5]]
              if ((pop1check == pop1 & pop2check == pop2) | (pop1check == pop2 & pop2check == pop1)){
                # then we need to check and see if these events are non-zero in the current model
                test <- 0
                newstartcheck <- list()
                for (n in 1:length(myhistoricinfo[[1]][[a]][[b]])){ # we want to check and see if the divergence times involved are non-zero in the model
                  historycheck <- myhistoricinfo[[1]][[a]][[b]][[n]]
                  historycheck <- strsplit(historycheck, split = " ")
                  historycheck <- historycheck[[1]][1]
                  for (m in 1:length(startcheck)){
                    if (startcheck[m] == historycheck) {
                      test <- test + 1
                      newstartcheck <- c(newstartcheck, startcheck[m])
                    }
                  }
                }
                if (test == length(startcheck)) { # if the test is the same length as start check, we know each divtime is non-zero in the model
                  migstart <- c(migstart,startcheck)
                  migend <- c(migend, stopcheck)
                }
                else if (test != length(startcheck)) { # otherwise, we should only consider non-zero divergence times.
                  migstart <- c(migstart,newstartcheck)
                  migend <- c(migend, stopcheck)
                }
              }
            }
          }
          replist <- list() # this is to check and see if all start times are zero.
          replist <- rep(list(0), length(migstart))
          migstartwrite <- paste(migstart)
          migendwrite <- paste(migend)
          # now, let's check to see if all items in mig start are 0. If, so only print migend info
          replist <- list() # this is to check and see if all start times are zero.
          replist <- rep(list(0), length(migstart))
          migendprint <- list()
          migstartprint <- list()
          if (all.equal(migstart, replist)[1] == TRUE){
            migrationcount <- migrationcount + 1
            # in this case, we only need to worry about the end time
            if (length(migend) == 1){
              # in this case it's fairly straightforward
              migendprint <- paste('1 Tmig', (migrationcount), 'end$ = ', migend[[1]], ' / 2 output', sep = "")
              # and this is all we need to write out in this case
              mylines[linecount] <- paste(migendprint)
              linecount <- linecount + 1
            }
            if (length(migend) == 2) {
              for (o in 1:length(migend)){
                migendprint <- paste('1 Tmig', (migrationcount), 'end', o, '$ = ', migend[[o]], ' / 2 output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
              }
            mylines[linecount] <- paste('1 Tmig', (migrationcount), 'end$ = ', 'Tmig', (migrationcount), 'end1$ %min% Tmig', (migrationcount), 'end2$ output', sep = "")
            linecount <- linecount + 1
            }
            if( length(migend) > 2) {
              for (p in 1:length(migend)){
                migendprint <- paste('1 Tmig', (migrationcount), 'end', p, '$ = ', migend[[p]], ' / 2 output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
              }
              for (q in 1:length(migend)){
                if (q == 1){
                  migendprint <- paste('1 Tmig', (migrationcount), 'end', length(migend)+q, '$ = ', 'Tmig', (migrationcount), 'end', q, ' %min% ', sep = "")
                }
                if (q == 2){
                  migendprint <- paste(migendprint, 'Tmig', (migrationcount), 'end', q, '$ output', sep = "")
                  mylines[linecount] <- paste(migendprint)
                  linecount <- linecount + 1
                }
                if (q > 2 & q != length(migend)) {
                  migendprint <- paste('1 Tmig', (migrationcount), 'end', length(migend) + q - 1, '$ = ', 'Tmig', (migrationcount), 'end', length(migend) + q - 2, ' %min% ', sep = "")
                  migendprint <- paste(migendprint, 'Tmig', (migrationcount), 'end', q, '$ output', sep = "")
                  mylines[linecount] <- paste(migendprint)
                  linecount <- linecount + 1
                }
                if (q > 2 & q == length(migend)){
                  migendprint <- paste('1 Tmig', (migrationcount), 'end$ = ', 'Tmig', (migrationcount), 'end', length(migend) + q - 2, ' %min% ', sep = "")
                  migendprint <- paste(migendprint, 'Tmig', (migrationcount), 'end', q, '$ output', sep = "")
                  mylines[linecount] <- paste(migendprint)
                  linecount <- linecount + 1
                }
              }
            }
          }
          else if (all.equal(migstart, replist)[1] != TRUE){
            migrationcount <- migrationcount + 1
            ## we need to deal with migration start times and migration end times
            ## now, let's deal with the migration start times
            ## unless we have more than two potential start times, this should be straight-forward
            if (length(migstart) == 1){
              if (migrationcount > 1 & coalescentinterval > 1) {
                migstartwrite <- paste('1 Tmig', migrationcount, '$ = ', migstart[[1]], ' %max% Tmig', (migrationcount - 1), 'end$ output', sep = "")
                mylines[linecount] <- paste(migstartwrite)
                linecount <- linecount + 1
              }
              else {
                migstartwrite <- paste('1 Tmig', migrationcount, '$ = ', migstart[[1]], '* 1 output', sep = "")
                mylines[linecount] <- paste(migstartwrite)
                linecount <- linecount + 1
              }
            }
            else if (length(migstart) == 2) {
              if (migrationcount > 1 & coalescentinterval > 1) {
                migstartwrite <- paste('1 Tmig', migrationcount, '_A$ = ', migstart[[1]], ' %max% ', migstart[[2]], sep = "")
                mylines[linecount] <- paste(migstartwrite)
                linecount <- linecount + 1
                migstartwrite <- paste('1 Tmig', migrationcount, '$ = ', 'Tmig', migrationcount, '_A$ %max% Tmig', (migrationcount - 1), 'end$ output', sep = "")
                mylines[linecount] <- paste(migstartwrite)
                linecount <- linecount + 1
              }
              else {
                migstartwrite <- paste('1 Tmig', migrationcount, '$ = ', migstart[[1]], ' %max% ', migstart[[2]], sep = "")
                mylines[linecount] <- paste(migstartwrite)
                linecount <- linecount + 1
              }
            }
            else if (length(migstart) > 2) {
              ## this one is slightly more complicated
              for(r in 1:length(migstart)){
                if (r == 1) {
                  migstartwrite <- paste('1 Tmig', migrationcount, '_', r, '$ = ', migstart[[r]], ' %max% ', sep = "")
                }
                if (r == 2) {
                  migstartwrite <- paste(migstart[[r]], ' output')
                  mylines[linecount] <- paste(migstartwrite)
                  linecount <- linecount + 1
                }
                if (r > 2) {
                  migstartwrite <- paste('1 Tmig', migrationcount, '_', (r - 1), '$ = ', 'Tmig', migrationcount, '_', (r-2), ' %max% ', migstart[[r]], 'output', sep = "")
                  mylines[linecount] <- paste(migstartwrite)
                  linecount <- linecount + 1
                }
              }
              mylines[linecount] <- paste('1 Tmig', migrationcount, '$ = ', 'Tmig', migrationcount, '_', length(migstart)-1, '$ * 1 output', sep = "")
              linecount <- linecount + 1
            }
            ## now, let's handle the end times
            if (length(migend) == 1){
              # in this case it's fairly straightforward
              migendprint <- paste('1 Tmig', (migrationcount), 'end1$ = ', migend[[1]], ' - Tmig', migrationcount, '$ output', sep = "")
              mylines[linecount] <- paste(migendprint)
              linecount <- linecount + 1
              migendprint <- paste('1 Tmig', (migrationcount), 'end2$ = ', 'Tmig', migrationcount, 'end1$ / 2 output', sep = "")
              mylines[linecount] <- paste(migendprint)
              linecount <- linecount + 1
              migendprint <- paste('1 Tmig', (migrationcount), 'end$ = ', 'Tmig', migrationcount, 'end2$ + Tmig', migrationcount, '$ output', sep = "")
              mylines[linecount] <- paste(migendprint)
              linecount <- linecount + 1
            }
            if (length(migend) == 2) {
              for (s in 1:length(migend)){
                migendprint <- paste('1 Tmig', (migrationcount), 'end', s, '_A$ = ', migend[[s]], ' - Tmig', migrationcount, '$ output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
                migendprint <- paste('1 Tmig', (migrationcount), 'end', s, '_B$ = ', 'Tmig', migrationcount, 'end', s, '_A$ / 2 output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
                migendprint <- paste('1 Tmig', (migrationcount), 'end', s, '_C$ = ', 'Tmig', migrationcount, 'end', s, '_B$ + Tmig', migrationcount, '$ output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
              }
              mylines[linecount] <- paste('1 Tmig', (migrationcount), 'end$ = ', 'Tmig', (migrationcount), 'end1_C$ %min% Tmig', (migrationcount), 'end2_C$ output', sep = "")
              linecount <- linecount + 1
            }
            if( length(migend) > 2) {
              for (t in 1:length(migend)){
                migendprint <- paste('1 Tmig', (migrationcount), 'end', t, '_A$ = ', migend[[t]], ' - Tmig', migrationcount, '$ output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
                migendprint <- paste('1 Tmig', (migrationcount), 'end', t, '_B$ = ', 'Tmig', migrationcount, 'end', t, '_A$ / 2 output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
                migendprint <- paste('1 Tmig', (migrationcount), 'end', t, '_C$ = ', 'Tmig', migrationcount, 'end', t, '_B$ + Tmig', migrationcount, '$ output', sep = "")
                mylines[linecount] <- paste(migendprint)
                linecount <- linecount + 1
              }
              theqcount <- 1
              for (u in 1:length(migend)){
                if (u == 1){
                  migendprint <- paste('1 Tmig', (migrationcount), 'end', theqcount, '$ = ', 'Tmig', (migrationcount), 'end', u, '_C$ %min% ', sep = "")
                }
                if (u == 2){
                  migendprint <- paste(migendprint, 'Tmig', migrationcount, 'end', q, '_C$ output')
                  mylines[linecount] <- paste(migendprint)
                  linecount <- linecount + 1
                  theqcount <- theqcount + 1
                }
                if( q > 2){
                  migendprint <- paste(migendprint, 'Tmig', migrationcount, 'end', theqcount, ' = ', 'Tmig', migrationcount, 'end', (theqcount-1), ' %min% ', 'Tmig', migrationcount, 'end', q, '_C$ output', sep = "")
                  mylines[linecount] <- paste(migendprint)
                  linecount <- linecount + 1
                  theqcount <- theqcount + 1
                }
              }
              migendprint <- paste(migendprint, 'Tmig', migrationcount, 'end$ = Tmig', migrationcount, 'end', length(migend) - 1, '$ * 1 output' )
            }
          }
        }
        write(paste(mylines,sep='\n'), file=paste(filename,'_',estfilecount,'.est',sep=""))
        estfilecount <- estfilecount+1
      }
    }
  }
}
