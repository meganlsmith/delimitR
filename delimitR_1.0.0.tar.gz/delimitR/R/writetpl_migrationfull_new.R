#' Generate .tpl files
#' @keywords internal

writetpl_mig_full <- function(samplesizes,nhistevents,histevents,
                              nsnps,filename,parseoutput,
                              mycollapsedhist,myhistoricinfo){
  thecount <- 1 # initialize a counter
  for(m in 1:length(myhistoricinfo[[1]])){ ## for each set of collapse history
    for(n in 1:length(myhistoricinfo[[1]][[m]])){ # for each migration history possibility for that collapse history
      linecount <- 1
      checklength<- length(myhistoricinfo[[1]][[m]][[n]]) # check to see how many possibilities there are, to see if the considered history includes migration
      comparelength <- length(mycollapsedhist[[1]]) # get the length of histories without migration events to compare to
      if(checklength==comparelength){ # if there are no migration events
        npotentialspec <- length(samplesizes) # the number of potential species is the number of samplesizes provided.
        ## the number of species should be equal to the length of the sample size vector
        popsizes <- c() # create an empty vector for pop sizes
        growthrates <- c() # create an empty vector for growth rates
        # fill the popsize and growth rate vectors
        for(i in 1:length(samplesizes)){
          popsizes[i] <- paste('N',(i-1),'$',sep='')
          growthrates[i]<-paste(0)
        }
        # since there is no migration:
        migration <- 0
        # empty history vector:
        thehistory <- c()
        # fill the history vector
        for(j in 1:length(mycollapsedhist[[m]])){
          thehistory[j] <- mycollapsedhist[[m]][j]
        }
        nlink <- 1
        datatype <- c('SNP',1,0,0,0.01)
        mylines <- list()
        mylines[linecount] <- '//Number of population samples (demes)'
        linecount <- linecount + 1
        mylines[linecount] <- as.character(npotentialspec)
        linecount <- linecount + 1
        mylines[linecount] <- '//Population effective sizes (number of genes)'
        linecount <- linecount + 1
        for(i in 1:length(samplesizes)){
          mylines[linecount] <- as.character(popsizes[i])
          linecount <- linecount + 1
        }
        mylines[linecount]<-'//Sample sizes'
        linecount <- linecount + 1
        for(j in 1:length(samplesizes)){
          mylines[linecount] <- as.character(samplesizes[j])
          linecount <- linecount + 1
        }
        mylines[linecount] <- '//Growth rates	: negative growth implies population expansion'
        linecount <- linecount + 1
        for(k in 1:length(samplesizes)){
          mylines[linecount] <- as.character(growthrates[k])
          linecount <- linecount + 1
        }
        mylines[linecount] <- '//Number of migration matrices : 0 implies no migration between demes'
        linecount <- linecount + 1
        mylines[linecount] <- as.character(migration)
        linecount <- linecount + 1
        mylines[linecount] <- '//historical event: time, source, sink, migrants, new size, new growth rate, migr. matrix '
        linecount <- linecount + 1
        mylines[linecount] <- paste(length(mycollapsedhist[[m]]),'historical event', sep=" ")
        linecount <- linecount + 1
        for(l in 1:length(thehistory)){
          mylines[linecount] <- paste(thehistory[l])
          linecount <- linecount + 1
        }
        mylines[linecount] <- '//Number of independent loci [chromosome]'
        linecount <- linecount + 1
        mylines[linecount] <- paste(nsnps, collapse=' ')
        linecount <- linecount + 1
        mylines[linecount] <- '//Per chromosome: Number of linkage blocks'
        linecount <- linecount + 1
        mylines[linecount] <- as.character(nlink)
        linecount <- linecount + 1
        mylines[linecount] <- '//per Block: data type, num loci, rec. rate and mut rate + optional parameters'
        linecount <- linecount + 1
        mylines[linecount] <- paste(datatype, collapse=' ')
        linecount <- linecount + 1
        write(paste(mylines,sep='\n'), file=paste(filename,'_',thecount,'.tpl',sep=""))
        thecount<- thecount+1

      }
      else if(checklength!=comparelength){ # otherwise, we need to deal with migration
          npotentialspec <- length(samplesizes)
          ## the number of species should be equal to the length of the sample size vector
          popsizes <- c()
          growthrates <- c()
          for(i in 1:length(samplesizes)){
            popsizes[i] <- paste('N',(i-1),'$',sep='')
            growthrates[i]<-paste(0)
          }
          migration <- length(myhistoricinfo[[1]][[m]][[n]])-length(mycollapsedhist[[1]])
          nhistevents <- length(myhistoricinfo[[1]][[m]][[n]])
          thehistory <- c()
          for(j in 1:length(myhistoricinfo[[1]][[m]][[n]])){
            thehistory[j] <- myhistoricinfo[[1]][[m]][[n]][[j]]
          }
          nlink <- 1
          datatype <- c('SNP',1,0,0,0.01)
          mylines <- list()
          mylines[linecount] <- '//Number of population samples (demes)'
          linecount <- linecount + 1
          mylines[linecount] <- as.character(npotentialspec)
          linecount <- linecount + 1
          mylines[linecount] <- '//Population effective sizes (number of genes)'
          linecount <- linecount + 1
          for(i in 1:length(samplesizes)){
            mylines[linecount] <- as.character(popsizes[i])
            linecount <- linecount + 1
          }
          mylines[linecount]<-'//Sample sizes'
          linecount <- linecount + 1
          for(j in 1:length(samplesizes)){
            mylines[linecount] <- as.character(samplesizes[j])
            linecount <- linecount + 1
          }
          mylines[linecount] <- '//Growth rates: negative growth implies population expansion'
          linecount <- linecount + 1
          for(k in 1:length(samplesizes)){
            mylines[linecount] <- as.character(growthrates[k])
            linecount <- linecount + 1
          }
          mylines[linecount] <- '//Number of migration matrices : 0 implies no migration between demes'
          linecount <- linecount + 1
          mylines[linecount] <- as.character((migration+1))
          linecount <- linecount + 1
          mylines[linecount] <- '//migration matrix'
          linecount <- linecount + 1
          for ( z in 1:length(samplesizes)) {
            mylines[linecount]<- paste(rep(0,npotentialspec),collapse=" ")
            linecount <- linecount + 1
          }
          for(p in 1:migration){
            matrixtowrite <- unlist(myhistoricinfo[[2]][[m]][[n-1]][p][[1]])
            mylines[linecount]<-'//migration matrix'
            linecount <- linecount + 1
            for(o in 1:nrow(matrixtowrite)){
              mylines[linecount]<-paste(unlist(matrixtowrite[o,]),collapse=" ")
              linecount <- linecount + 1
            }
            nonzero <-(which(matrixtowrite!=0,arr.ind=T))
          }
          mylines[linecount] <- '//historical event: time, source, sink, migrants, new size, new growth rate, migr. matrix '
          linecount <- linecount + 1
          mylines[linecount] <- paste((length(mycollapsedhist[[m]])+migration*2),'historical event', sep=" ")
          linecount <- linecount + 1
          counter=0
          count2 = 0
          for(l in 1:length(thehistory)){
            mylines[linecount] <- paste(thehistory[l])
            linecount <- linecount + 1
            checkhistory <- strsplit(thehistory[l],split=" ")[[1]]
            checkhistory1 <- checkhistory[2]
            checkhistory2 <- checkhistory[3]
            if(!is.na(checkhistory[1])){
              if(checkhistory1=="0" & checkhistory2=="0"){
                newhistory <- strsplit(thehistory[l],split=" ")[[1]][1]
                count2 = count2+1
                newhistory <- strsplit(newhistory,split="\\$")[[1]][1]
                newhistwrite <- paste('Tmig', count2, 'end','$',sep="")
                fullwrite <- paste(newhistwrite,"0 0 0 1 0 0")
                #print(fullwrite)
                mylines[linecount]<-fullwrite
                linecount <- linecount + 1
                counter <- counter+1
              }
            }
          }
          mylines[linecount] <- '//Number of independent loci [chromosome]'
          linecount <- linecount + 1
          mylines[linecount] <- paste(nsnps, collapse=' ')
          linecount <- linecount + 1
          mylines[linecount] <- '//Per chromosome: Number of linkage blocks'
          linecount <- linecount + 1
          mylines[linecount] <- as.character(nlink)
          linecount <- linecount + 1
          mylines[linecount] <- '//per Block: data type, num loci, rec. rate and mut rate + optional parameters'
          linecount <- linecount + 1
          mylines[linecount] <- paste(datatype, collapse=' ')
          linecount <- linecount + 1
          write(paste(mylines,sep='\n'), file=paste(filename,'_',thecount,'.tpl',sep=""))
          thecount <- thecount+1
      }
    }
  }
}



