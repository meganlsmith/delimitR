## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----obsfigure, out.width= "700 px"--------------------------------------
knitr::include_graphics('/Users/peglegmeg/Desktop/delimitR/vignettes/observedsfsfigure.png')

## ----observedtraitsfig, out.width= "100 px", echo = FALSE----------------
knitr::include_graphics('/Users/peglegmeg/Desktop/delimitR/vignettes/observedtraits.png')

## ----guidetreefigure, out.width= "100 px", echo = FALSE------------------
knitr::include_graphics('/Users/peglegmeg/Desktop/delimitR/vignettes/myspeciestree.png')

## ----maxcoalfig, out.width= "500 px", echo = FALSE-----------------------
knitr::include_graphics('/Users/peglegmeg/Desktop/delimitR/vignettes/models_max1.png')

## ----maxcoalfig2, out.width= "500 px", echo = FALSE----------------------
knitr::include_graphics('/Users/peglegmeg/Desktop/delimitR/vignettes/models_max2.png')

## ----divtimes, out.width= "300 px", echo = FALSE-------------------------
knitr::include_graphics('/Users/peglegmeg/Desktop/delimitR/vignettes/coalescentintervals.png')

