library(testthat)
library(delimitR)

test_check("delimitR")
