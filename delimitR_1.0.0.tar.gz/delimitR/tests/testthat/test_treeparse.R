context("Tree parser")

tree1 <- '(0,1);'
tree2 <- '((0,1),2);'
tree3 <- '(0,(1,2));'
tree4 <- '((0,1),(2,3));'
tree5 <- '(((0,1),2),(3,4))'


test_that("tree processor finds the correct number of coalescent units", {
  expect_equal(length(parsetree(tree1)),1)
  expect_equal(length(parsetree(tree2)),2)
  expect_equal(length(parsetree(tree3)),2)
  expect_equal(length(parsetree(tree4)),2)
  expect_equal(length(parsetree(tree5)),3)
})
